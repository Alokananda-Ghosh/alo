package com.cg.Dao;

public interface QueryMapping 
{
static final String  INSERT_QUERY="insert into Product values(seqpid.nextval,?,?,?,?)";
static final String RETRIEVE_QUERY="select * from Product ";
static final String SEQ_QUERY="Select seqpid.currVal from Dual";
static final String DELETE_QUERY="delete from Product where productid=?";
}
