package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Product;

public class CollectionUtil
{
private static HashMap<Integer,Product> products=new HashMap<Integer,Product>();

public static void setProducts(Product p)
{
	products.put(p.getProductid(),p);
}
public static HashMap<Integer, Product> getProducts()
{
	return products;
	
}

}
